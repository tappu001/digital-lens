// Deployment settings for the hosted Digital Lens™ version.
// After you deploy the Cloudflare Worker (see DEPLOY.md), paste its URL here and commit.
// Every visitor will then use it automatically. Users can still override it in Settings.
window.TSD_CONFIG = {
  proxyUrl: 'https://tagscope-proxy.dudhrejiyatapasvi.workers.dev',
};
